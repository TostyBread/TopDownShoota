// WEAPONS //
There will be only 5 total weapon in this game, and it can be categorized with 3 types; Gel blaster, water blaster, and food.

== GEL BLASTERS ==
Auto Deagle and Burst MP5 are both gel blaster, and as the name had implied its meaning, one has automatic shooting funtion
while another has burst fire funtion. It both uses gel balls that deals 4 damage to the hungry cats.

Auto Deagle has 25 in a mag capacity, Spread of 8, ROF 0.15, and reload time of 2 seconds
Burst MP5 has 30 in a mag capacity, Spread of 5, ROF 0.2, Burst interval 0.1, Burst amount 3, and reload time of 2 seconds.

== WATER BLASTER ==
Spray bottle and Water/ Squirt gun are both water blaster. It both uses water that deals 2 damage to the enemy.

Spary bottle acts like a shotgun in this game, it shoots 3 pellets everytime it fires. It has 12 in a mag capacity, 
Spread of 10, Spread angle of 20, and reload time of 1.5 seconds.

Water/Squirt gun is basically like a semi-auto handgun, it has 20 in a mag capacity, Spread of 3, and reload time of 1.5 sec.

== FOOD ==

The only food in this game are use to neutralize the hungry cat, so don't try to eat it, because you can't.
Catfood is a throwable weapon that attracts hungry cats to eat it, it has a serving about 3 to 4 cats (more or less)
before its empty. It has a reload time of 7.3 seconds.


** Note: the damage maybe inconsistent, take this guide as a instruction manual for understanding purposes **


// ENEMIES //
There are only 2 types of hungry cats in this game, one is orange and the other is white.

The orange cat, or commonly refers as stupid one in the internet, has a speed of 3.5, Health of 5 and damage of 1.

The white cat has a speed of 4.5, Health of 9 and damage of 2

In terms of Lootdrop, both types of hungry cats can drop all 5 types of weapons and health kit except with 7% chance.

The difficulty rate will increase every 30 seconds passed, basically very slowly increases the spawn rate of the hungry cats.
Default minimum spawn interval and maximum spawn intervals are between 1 to 3 seconds every start of the game.


** Note: another technical issue I cant figure out why both takes same amount of damage to eliminate... Other than that, the
   damage they deal are both different **


// PLAYER //
The player, or known as pissed owner is a player controlled character that has 10 health and a movement speed of 5.5.
Pissed owner can pick up weapons and use one weapon until running by another weapon and health pack drops to heal 3 health.




// OBJECTIVES //
Being the last man standing in these dire situation, you are basically trying to survive as long as you can.
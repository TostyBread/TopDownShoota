ASSETS CREDITS:

//WEAPONS//
Spray bottle image- https://www.shoprite.co.za/All-Departments/Outdoor/Garden/Garden-and-Irrigation-Accessories/Quality-Trigger-Spray-Bottle/p/10112577EA
Water gun image- https://combatarms.fandom.com/wiki/Squirt_Gun
MP5 image - CYMA Gel Blaster
Desert Eagle image- CS GO
Crosshair = Lucian Pavel in opengameart.org
Cat food image = DayZ
Health pickup image - Halo: Reach's health kit

Desert Eagle equiped image - Drawn by Kenji
MP5 equiped image - Drawn by Kenji
Spray Bottle equiped image - Drawn by Kenji
Water gun equiped image - Drawn by Kenji

//CHARACTERS//
Pissed owner (Rick Astley, player controlled character)- Drawn by Kenji
Hungry cat (White and Orange, Enemy) - Drawn by Kenji

//SFX//
Water spraying sfx (Water gun and Spray bottle) - Soundsnap website
Cat scream sfx - Minecraft, and popular cat screaming meme
Weapon equip, reload sound & healing - Valve's Half-Life
Gel blaster sfx - ZapSplat website
Can opening sfx - Utility Sounds(Youtube)
Cat eating sfx - huh
Shared sfx (cat hitting food & player hurt) - Minecraft Damage sfx
Player killed sfx - Scream fade meme
Hitting non character sfx - Tommy's Ricochet sfx

//PROPS//
Generic box - Drawn by Kenji
Generic Barrel - Drawn by Kenji
Generic SupplyRack - Drawn by Kenji
Generic StackBoxes - Drawn by Kenji

//BACKGROUND & ENVIRONMENT//
ArenaBattlemap - Drawn by Kenji
WarehouseBattlemap - Drawn by Kenji
Main Menu background - Drawn by Kenji


Version 1.1.3 [made by Tan Kenji, aka Elite Spec-Ops Alan]

-- Fixed issues --

- Aspect ration locked at 1080p, anything more than that will cause UI issue.
- Highest survived time added alongside reset button.
- mouse cursor didn't show up after player died, causing it unable to continue playing game.
- Balancing issue regarding player able to outrun cats easily.
- Fixed Rigidbody collider wall not representing what it looks at Warehouse survival map
- Seperated orange cat and white cat prefab to avoid inconsistance damage output/ same health
- Fixed bullet projectile goes "under" the wall
- Fixed cat food collision with obstacles not working